import sys
import os
import json
import re
import shutil

from pathlib import Path

from common.llm_init import LLMInitializer
from common.input_handler import get_user_prompt
from common.tool_definitions import read_file
from common.execute_tool import execute_tool
from common.guardrail_tools import check_context_guardrail
from common.output_handler import stream_agent_response

from coding_agent.welcome_banner import display_welcome_banner
from coding_agent.system_prompt_builder import build_system_prompt
from coding_agent.native_helpers import (get_repo_structure, generate_requirements_native, gather_deep_context,
                                         gather_deep_context_ast)
from coding_agent.guardrail_tools import (verify_sandbox_health, auto_heal_newline_escaping,
                                          find_last_code_block, run_self_verification)
from coding_agent import hidden_readme_prompt_builder
from coding_agent import split_tools
from coding_agent import payload_parser

from cli import parse_cli_arguments
# the agent currently supports: Qwen2.5-Coder-7B-Instruct-Q4_K_M/Q5_K_M
from model_registry import MODEL_REGISTRY


class AgentState:
    def __init__(self, parsed_args):
        self.allow_patch = parsed_args["allow_patch"]
        self.force_testing = parsed_args["force_testing"]
        self.self_verify_py_writes = parsed_args["self_verify_py_writes"]
        self.kv_quantization_type = parsed_args["kv_quantization_type"]


        self.active_config = MODEL_REGISTRY[parsed_args["model"]]

        self.target_path = Path(__file__).resolve().parent / "models" / self.active_config["filename"]
        self.loaded_model_name = self.active_config["display_name"]

        self.messages = []
        self.session_cwd = os.getcwd()

class AgentExecutionState:
    def __init__(self):
        self.is_split_mode: bool = False  # Indicates whether the agent is currently in split mode
        self.is_execute_mode: bool = False  # Indicates whether the agent is using AST interception
        self.original_split_file: str | None = None  # Stores the original file path when in split mode
        self.sandbox_directory: str | None = None  # Stores the path to the sandbox directory when in split mode
        self.automated_followup: str | None = None  # Buffer for system-generated prompt injections
        self.has_prompted_for_tests: bool = False  # Indicates whether the agent has prompted the user for tests

parsed_args = parse_cli_arguments(MODEL_REGISTRY.keys())
state = AgentState(parsed_args)
execution_state = AgentExecutionState()


def handle_user_input(state, user_input, system_prompt):
    if user_input == "/quit":
        print("Exiting. Goodbye!")
        sys.exit(0)

    if user_input == "/clear":
        state.messages = [{"role": "system", "content": system_prompt}]
        state.session_cwd = os.getcwd()
        state.consult_read_cache = {}
        print("🧹 Memory and environment completely cleared!")
        return True

    if user_input == "/cancel":
        print("❌ Current draft discarded.")
        return True

    if not user_input:
        return True

    return False


def handle_macros(user_input, state, execution_state, system_prompt):
    """
    Handles the more complex macros. Returns True if a relevant macro was found but an error occurred
    and False if everything went right or no relevant macro was found.
    """
    # --- MACRO: /requirements ---
    if user_input.startswith("/requirements"):
        no_version_flag = "--no-version" in user_input
        cleaned_input = user_input.replace("--no-version", "").strip()
        parts = cleaned_input.split(" ", 1)
        target_dir = parts[1].strip() if len(parts) > 1 and parts[1].strip() else "."

        abs_target_dir = os.path.abspath(os.path.expanduser(target_dir))
        state.session_cwd = abs_target_dir

        if not os.path.isdir(abs_target_dir):
            print(f"❌ Error: Target directory '{abs_target_dir}' does not exist.")
            return True

        print(f"\n⚠️  MANUAL OVERRIDE: Generate requirements.txt natively? (No versions: {no_version_flag})")
        approval = input("Allow this action? (y/n): ").strip().lower()

        if approval == 'y':
            tool_result = generate_requirements_native(abs_target_dir, no_version=no_version_flag)
            state.messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user",
                 "content": f"System Alert: User manually ran /requirements for '{abs_target_dir}'. Result: {tool_result}. Briefly acknowledge completion."}
            ]
        else:
            print("🛑 Action blocked.")
            return True

        return False

    # --- MACRO: /readme ---
    elif user_input.startswith("/readme"):
        # 1. Split input into whole-word tokens to avoid substring match bugs
        tokens = user_input.split()

        deep_focus = "--deep" in tokens or "-d" in tokens
        deep_ast_focus = "--deep-ast" in tokens

        # 2. Filter out the command and the flags
        flags_to_remove = {"/readme", "--deep", "-d", "--deep-ast"}
        path_tokens = [t for t in tokens if t not in flags_to_remove]

        # 3. Join the remaining tokens to form the path (handles unquoted paths with spaces)
        target_dir = " ".join(path_tokens) if path_tokens else "."

        abs_target_dir = os.path.abspath(os.path.expanduser(target_dir))
        state.session_cwd = abs_target_dir

        if not os.path.isdir(abs_target_dir):
            print(f"❌ Error: Target directory '{abs_target_dir}' does not exist.")
            return True

        print(f"\n🔍 Pre-computing repository structure for {abs_target_dir}...")

        repo_tree = get_repo_structure(abs_target_dir)
        readme_path = os.path.join(abs_target_dir, "README.md")

        if os.path.exists(readme_path):
            existing_readme = read_file(readme_path, start_line=1, max_lines=1000)
            print("   [Notice] Existing README.md found. Forcing structural analysis.")
        else:
            existing_readme = "No existing README.md found. Create from scratch."
            print("   [Notice] No README.md found. Agent will draft a new one.")

        # Deep Mode Trigger Interceptor
        code_summary = None
        cli_help = None
        if deep_ast_focus:
            print(
                "👀 [Mode Change] Experimental Dispatcher: Extracting AST interfaces and auto-routing based on size...")
            code_summary, cli_help = gather_deep_context_ast(abs_target_dir)
        elif deep_focus:
            print("👀 [Mode Change] Deep Scan: Extracting script code segments and querying CLI help hooks...")
            code_summary, cli_help = gather_deep_context(abs_target_dir)

        strategy_steps = hidden_readme_prompt_builder.build_strategy_steps(
            readme_path, state.allow_patch,
            deep_focus=(deep_focus or deep_ast_focus)
        )

        hidden_readme_prompt = hidden_readme_prompt_builder.build_hidden_readme_prompt(
            abs_target_dir, repo_tree, existing_readme, strategy_steps, code_summary=code_summary,
            cli_help=cli_help
        )

        state.messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": hidden_readme_prompt}
        ]

        return False

    # --- MACRO: /split ---
    elif user_input.startswith("/split"):
        execute_mode = "--execute" in user_input
        cleaned_args = user_input.replace("--execute", "").strip().split(" ", 1)

        if len(cleaned_args) < 2 or not cleaned_args[1].strip():
            print("❌ Error: You must provide a filepath. Usage: /split [--execute] [filepath]")
            return True

        target_file = cleaned_args[1].strip()
        abs_target_file = os.path.abspath(os.path.expanduser(target_file))

        if not os.path.isfile(abs_target_file):
            print(f"❌ Error: Target file '{abs_target_file}' does not exist.")
            return True

        if execute_mode:
            print(
                f"\n⚠️  [WARNING] Execution Mode Active: System will use AST natively based on LLM JSON mapping.")
            print("   This isolates the agent from hallucinating logic blocks.")
            print(f"🔍 Initializing Sandbox and Parsing AST structure for {abs_target_file}...")
        else:
            print(f"\n🔍 Initializing Sandbox (Advisor Mode) for {abs_target_file}...")

        # 1. Setup sandbox tracking
        _, execution_state.sandbox_directory = split_tools.setup_refactor_sandbox(abs_target_file)
        execution_state.original_split_file = abs_target_file
        execution_state.is_split_mode = True
        execution_state.is_execute_mode = execute_mode

        # 2. Divert agent's current working directory to the sandbox!
        state.session_cwd = execution_state.sandbox_directory

        # Pass the flag to the prompt builder
        split_prompt = split_tools.build_split_prompt(abs_target_file, state.session_cwd, execute_mode=execute_mode)

        if not execute_mode:
            split_prompt += "\n\nFormat your plan now. Do not write file contents yet. Wait for confirmation."

        state.messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": split_prompt}
        ]

        return False

    return False  # Return False if no macro was handled


def handle_ast_extraction_interception(state, execution_state, response_content):
    if "```json" in response_content:
        if execution_state.is_execute_mode:
            handled, alert = split_tools.handle_ast_extraction(response_content,
                                                               execution_state.original_split_file,
                                                               execution_state.sandbox_directory)
        else:
            print("\n📋 Advisor blueprint received:")
            approval = input(
                "Apply this blueprint deterministically to the sandbox? (y/n): ").strip().lower()
            if approval == 'y':
                handled, alert = split_tools.handle_ast_extraction(response_content,
                                                                   execution_state.original_split_file,
                                                                   execution_state.sandbox_directory)
            else:
                handled, alert = True, (
                    "Blueprint held pending revision. If you'd like changes, "
                    "explain them and provide an updated ```json blueprint."
                )
        if handled:
            state.messages.append({"role": "user", "content": alert})
            return True
    return False


def handle_sandbox_guardrail(execution_state, state, response_content):
    """SANDBOX GUARDRAIL: Only runs if NO tool was called."""
    if any(x in response_content.lower() for x in ["refactor phase complete", "task complete"]):
        passed, report = verify_sandbox_health(execution_state.original_split_file,
                                               execution_state.sandbox_directory, state.messages)
        if passed:
            print(f"✅ Sandbox passed! Staged in: {execution_state.sandbox_directory}")
            if execution_state.is_execute_mode:
                # Promotion done only in execute mode, just for safety
                if input("Promote to production? (y/n): ").strip().lower() == 'y':
                    target_dir = os.path.dirname(execution_state.original_split_file)
                    for item in os.listdir(execution_state.sandbox_directory):
                        if not item.startswith('.'):
                            shutil.copy2(os.path.join(execution_state.sandbox_directory, item),
                                         os.path.join(target_dir, item))
                    print("🚀 Files successfully promoted.")
            execution_state.is_split_mode = execution_state.is_execute_mode = False
            state.session_cwd = os.path.dirname(execution_state.original_split_file)
            return True
        print(f"❌ Verification Failed:\n{report}")
        state.messages.append({"role": "user",
                               "content": f"System Verification Failed:\n{report}\n\nCorrect this error and output 'Refactor Phase Complete'."})
        return False
    return False


def handle_automated_follow_up(state, agent_flags, execution_state, tool_args):
    """Automated follow-up trigger"""
    if state.force_testing and agent_flags.file_was_modified and not execution_state.is_split_mode:
        # Directly use .get() since tool_args is guaranteed to be a dict
        raw_path = tool_args.get("filepath", "")
        fn = Path(raw_path).name.lower()
        if (raw_path and fn.endswith(".py") and
                (fn.startswith("test_") or fn.endswith("_test.py")) and not execution_state.has_prompted_for_tests):
            print("\n[System]: Automatically queuing follow-up test prompt.")
            safe_exec = sys.executable.replace("\\", "/")
            state.messages.append({"role": "user",
                                   "content": f"Great. Use `run_cmd` (e.g. `\"{safe_exec}\" -m unittest`) to verify. If a test fails, analyze if the test itself is wrong before fixing the source code."})
            execution_state.has_prompted_for_tests = True
        else:
            print("\n[System]: Main script written / modified.")


def check_and_handle_identical_write(tool_args, state, agent_flags, content_key):
    """
    Checks if the proposed content is identical to the existing content in the file.
    If identical, blocks the write operation and provides a guardrail message.
    """
    target_fp = tool_args.get("filepath", "")
    if os.path.isfile(target_fp):
        try:
            with open(target_fp, "r", encoding="utf-8") as f:
                existing_disk_content = f.read()

            proposed_content = tool_args.get(content_key, "")
            if existing_disk_content.strip() == proposed_content.strip():
                print(
                    f"🛡️  [Guardrail] Blocked identical write_file to '{os.path.basename(target_fp)}' (No-Op Regurgitation).")

                agent_flags.consecutive_errors += 1
                if agent_flags.consecutive_errors >= 3:
                    print(
                        "🛑 [Circuit Breaker] Agent stuck in identical write loop. Forcing turn end.")
                    return True

                # Context-Aware Guardrail Message
                if agent_flags.last_verification_failure and agent_flags.last_verification_failure.get(
                        "filepath") == target_fp:
                    alert_msg = (
                        f"System Alert: `write_file` blocked. You attempted to overwrite '{target_fp}' with the EXACT SAME BROKEN CODE that just failed self-verification. "
                        f"You must actually CHANGE the code to fix the error.\nError was:\n{agent_flags.last_verification_failure.get('error', '')}")
                    if "unterminated string literal" in agent_flags.last_verification_failure.get(
                            "error", ""):
                        alert_msg += "\nHint: If you used '\\n' inside a Python string, the JSON parser converted it to a real newline. Avoid using '\\n' in string literals (e.g. use multiple prints) or quadruple-escape it as `\\\\n`."
                else:
                    alert_msg = (
                        f"System Alert: `write_file` on '{target_fp}' was blocked because the new content is IDENTICAL to the existing file on disk. "
                        f"If the user only asked to read, analyze, inspect, or explain, DO NOT invoke write tools. Answer directly in plain text.")

                state.messages.append({
                    "role": "user",
                    "content": alert_msg
                })
                return True
        except Exception:
            pass
        return False


def check_and_handle_loop_guardrail(tool_name, tool_args, agent_flags):
    """
    Checks if the same tool call has been attempted recently and blocks it if it has.
    If the same tool call is repeated more than twice, it triggers a circuit breaker.
    """
    curr_sig = f"{tool_name}:{str(tool_args)}"
    agent_flags.recent_tool_signatures.append(curr_sig)
    agent_flags.recent_tool_signatures = agent_flags.recent_tool_signatures[-6:]  # keep a short rolling window

    repeat_count = agent_flags.recent_tool_signatures.count(curr_sig)
    if repeat_count >= 2:
        agent_flags.consecutive_errors += 1
        if agent_flags.consecutive_errors >= 3:
            print("🛑 [Circuit Breaker] Agent loop. Forcing turn end.")
            return True
        state.messages.append({"role": "user",
                               "content": f"System Alert: This exact tool call has been attempted {repeat_count} times "
                                          f"recently and is not succeeding. Do not repeat it verbatim — either fix the "
                                          f"underlying issue (e.g. re-check content/context requirements) or try a "
                                          f"different approach."})
        return True
    return False


def handle_self_verification_and_healing(state, tool_name, tool_args, agent_flags,
                                         tool_reinforcement, was_mod, tool_result):
    if state.self_verify_py_writes and was_mod and tool_name in ["write_file", "append_file",
                                                                 "patch_file", "replace_lines"]:
        fp = tool_args.get("filepath", "")
        if linter_error := run_self_verification(fp):
            # --- AUTO-HEALER FOR JSON NEWLINE ESCAPING ---
            if "unterminated string literal" in linter_error:
                try:
                    healed, new_lines = auto_heal_newline_escaping(fp)
                    if healed:
                        with open(fp, "w", encoding="utf-8") as f:
                            f.writelines(new_lines)

                        # Re-verify after healing
                        linter_error = run_self_verification(fp)
                        if not linter_error:
                            print(
                                f"🔧 [Auto-Healer] Successfully repaired JSON newline escaping artifact in {os.path.basename(fp)}!")
                            agent_flags.consecutive_lint_failures = 0
                            agent_flags.last_verification_failure = None
                            # Skip the rest of the failure block since it's fixed!
                            return True, tool_reinforcement
                except Exception as e:
                    print(f"⚠️ Auto-healer encountered an exception: {e}")
            # ---------------

            agent_flags.consecutive_lint_failures += 1
            print(f"🚨 [Self-Verification] FAILED on {os.path.basename(fp)}:\n{linter_error}")

            tool_reinforcement += f"\n\nSystem Alert: Syntax check failed:\n{linter_error}\nFix it."

            # Amnesia patch to prevent repetition loops
            if state.messages and state.messages[-1].get("role") == "assistant":
                old_content = state.messages[-1].get("content", "")
                if len(old_content) > 50:
                    state.messages[-1][
                        "content"] = f"[Action logged: write_file to {fp}. Full JSON payload redacted to prevent repetition collapse.]"

            if agent_flags.consecutive_lint_failures >= 3:
                print("🛑 [Circuit Breaker] Repeated lint failures. Forcing turn end.")
                state.messages.append(
                    {"role": "user", "content": f"Tool Result:\n{tool_result}{tool_reinforcement}"})
                return False, tool_reinforcement
        else:
            if agent_flags.consecutive_lint_failures > 0: print(
                f"✅ {os.path.basename(fp)} now passes checks.")
            agent_flags.consecutive_lint_failures, agent_flags.last_verification_failure = 0, None
            return True, tool_reinforcement
    return True, tool_reinforcement


def main(state, execution_state):
    system_prompt = build_system_prompt()

    initializer = LLMInitializer(state.target_path, state.loaded_model_name, state.active_config, state.kv_quantization_type)
    initializer.initialize_agent()
    context_window = initializer.CONTEXT_WINDOW
    llm = initializer.llm

    state.messages = [{"role": "system", "content": system_prompt}]

    display_welcome_banner(state.loaded_model_name, state.allow_patch)

    while True:
        # Check if we have an automated follow-up prompt queued
        if execution_state.automated_followup:
            user_input = execution_state.automated_followup
            execution_state.automated_followup = None
            print(f"\n[Automated User]: {user_input}")
        else:
            # smart input handler
            user_input = get_user_prompt()

        if handle_user_input(state, user_input, system_prompt):
            continue

        if handle_macros(user_input, state, execution_state, system_prompt):
            continue

        # Standard execution or continuation of sandbox mode
        state.messages.append({"role": "user", "content": user_input})

        class AgentFlags:
            def __init__(self):
                self.file_was_modified = False  # Track if any files change during this cycle
                self.last_tool_call_signature = None  # Track the last tool run
                self.consecutive_errors = 0   # Track infinite loop traps
                self.consecutive_lint_failures = 0  # Track repeated self-verification failures on the same turn
                self.last_verification_failure = None  # Track {filepath, content, error} of the last failed lint, to detect stale-fix reuse
                self.recent_tool_signatures = []  # Loop Guardrail: track recent signatures, not just the immediately previous one

        agent_flags = AgentFlags()
        tool_args = {}  # Very important: this must exist in the first iteration

        # Internal Agent Execution Loop
        while True:
            check_context_guardrail(state.messages, llm, context_window)

            try:
                response_content, is_truncated, interrupted = stream_agent_response(llm, state.messages)
                if interrupted:
                    break

                if execution_state.is_split_mode:
                    if handle_ast_extraction_interception(state, execution_state, response_content):
                        continue

                # Check for tool calls FIRST. Never let "Refactor Phase Complete"
                # short-circuit a turn that also contains a tool call.
                tool_request = payload_parser.extract_tool_call(response_content, allow_patch=state.allow_patch)

                if not tool_request:
                    if execution_state.is_split_mode:
                        if handle_sandbox_guardrail(execution_state, state, response_content):
                            continue

                    handle_automated_follow_up(state, agent_flags, execution_state, tool_args)

                    break

                tool_name = tool_request.get("name")
                tool_args = tool_request.get("args", {})

                # --- PRE-FLIGHT VALIDATION & GUARDRAILS ---
                if tool_name in ["read_file", "run_cmd"] and "<payload>" in response_content:
                    state.messages.append({"role": "user",
                                     "content": f"System Alert: Tool `{tool_name}` does NOT accept <payload> blocks. Retry with ONLY the JSON block."})
                    continue

                if is_truncated and tool_name == "write_file":
                    raise json.JSONDecodeError("Incomplete payload due to context limit.", "", 0)

                # Path resolution
                for key in ["filepath", "dir_path"]:
                    if key in tool_args and not os.path.isabs(tool_args[key]):
                        tool_args[key] = os.path.abspath(os.path.join(state.session_cwd, tool_args[key]))

                # Define standard payload key handling
                content_key = "new_content" if tool_name == "patch_file" else "content"

                # Payload recovery, empty file guard & no-op / regurgitation guardrail
                if tool_name in ["write_file", "append_file", "patch_file", "replace_lines"]:
                    content_clean = re.sub(r'```[a-zA-Z]*\s*```', '', tool_args.get(content_key, '')).strip()

                    if not content_clean:
                        recovered = find_last_code_block(state.messages)
                        is_stale = bool(recovered and agent_flags.last_verification_failure and
                                        agent_flags.last_verification_failure.get("filepath") == tool_args.get("filepath") and
                                        recovered.strip() == agent_flags.last_verification_failure.get("content", "").strip())

                        if recovered and recovered.strip() and not is_stale:
                            print(f"🔧 [Recovery] Reusing last drafted code block for {tool_name}.")
                            tool_args[content_key] = recovered
                        else:
                            msg = (f"System Alert: Blocked empty {tool_name}." if not is_stale else
                                   f"System Alert: Stale-Fix Guard. You provided the SAME failing code again.\n{agent_flags.last_verification_failure.get('error', '')}")
                            msg += f"\nYou MUST provide the corrected code inside a <payload> block. Retry {tool_name}."

                            agent_flags.consecutive_errors += 1
                            if agent_flags.consecutive_errors >= 3:
                                print("🛑 [Circuit Breaker] Agent stuck in syntax loop. Forcing exit.")
                                break
                            state.messages.append({"role": "user", "content": msg})
                            continue

                        if tool_name == "write_file":
                            if check_and_handle_identical_write(tool_args, state, agent_flags, content_key):
                                continue

                if check_and_handle_loop_guardrail(tool_name, tool_args, agent_flags):
                    continue

                # --- EXECUTION ---
                print(f"\n⚠️  AGENT REQUESTS EXECUTION: {tool_name}")

                target_code = tool_args.get(content_key, '')

                if tool_name in ["write_file", "append_file", "patch_file", "replace_lines"]:
                    if tool_name == "patch_file":
                        old_snip = tool_args.get('old_content', '')
                        print(
                            f"Target: {tool_args.get('filepath')}\n"
                            f"--- Replacing ---\n{old_snip}\n"
                            f"--- With ---\n{target_code}\n{'-' * 20}"
                        )
                    else:
                        line_count = target_code.count('\n') + 1 if target_code else 0
                        MAX_PREVIEW_CHARS = 5000
                        if len(target_code) > MAX_PREVIEW_CHARS:
                            shown = target_code[:MAX_PREVIEW_CHARS]
                            print(
                                f"Target: {tool_args.get('filepath')} ({line_count} lines, showing first {MAX_PREVIEW_CHARS} chars)\n{'-' * 20}\n{shown}\n...\n{'-' * 20}")
                        else:
                            print(
                                f"Target: {tool_args.get('filepath')} ({line_count} lines)\n{'-' * 20}\n{target_code}\n{'-' * 20}")
                else:
                    print(f"Arguments: {tool_args}")

                approval = input("Allow this action? (y/n/edit): ").strip().lower()
                tool_result, tool_reinforcement = "", ""

                if approval == 'y':
                    tool_result, tool_reinforcement, was_mod = execute_tool(tool_name, tool_args, execution_state.is_split_mode)
                    agent_flags.file_was_modified = agent_flags.file_was_modified or was_mod
                    print(f"⚙️  Tool execution finished.")

                    # Auxiliary output of the tool_result, useful for debugging
                    MAX_RESULT_PREVIEW = 400
                    # MAX_RESULT_PREVIEW = 2000
                    if len(tool_result) > MAX_RESULT_PREVIEW:
                        preview = tool_result[:MAX_RESULT_PREVIEW]
                        print(f"   Result ({len(tool_result)} chars, truncated): {preview}...")
                    else:
                        print(f"   Result: {tool_result}")

                    # Self-Verification
                    success, tool_reinforcement = handle_self_verification_and_healing(state, tool_name, tool_args,
                                                                                       agent_flags, tool_reinforcement, was_mod,
                                                                                       tool_result)
                    if not success:
                        state.messages.append(
                            {"role": "user", "content": f"Tool Result:\n{tool_result}{tool_reinforcement}"})
                        break

                    tool_reinforcement += f"\n\nSystem Alert: Tool executed successfully."

                    state.messages.append(
                        {"role": "user", "content": f"Tool Execution Result:\n{tool_result}{tool_reinforcement}"})

                elif approval == 'edit':
                    tool_result = f"User denied and provided feedback: {input('Feedback: ')}"
                else:
                    tool_result = "User denied permission."
                    print("🛑 Action blocked.")

                state.messages.append(
                    {"role": "user", "content": f"Tool Execution Result:\n{tool_result}{tool_reinforcement}"})

            # potential recovery from misformatted JSONs
            except json.JSONDecodeError as e:
                print(f"\n❌ [Parser Interceptor] Caught JSON error, feeding back to agent...")
                error_msg = (
                    f"⚠️ ACTION FAILED: Your tool call was NOT executed because the JSON is invalid.\n"
                    f"JSON Error: {str(e)}\n\n"
                    f"Hint: In JSON, you cannot escape single quotes like \\'. To put a literal backslash "
                    f"and a quote in Python code via JSON, you must double-escape the backslash: \\\\', "
                    f"or avoid illegal JSON escape sequences. Please fix your JSON and try again."
                )
                state.messages.append({"role": "user", "content": error_msg})

                agent_flags.consecutive_errors += 1
                if agent_flags.consecutive_errors >= 3:
                    print("🛑 [Circuit Breaker] Agent stuck in JSON formatting loop. Forcing exit.")
                    break

                continue  # CRITICAL: 'continue' lets the agent retry instantly

            except Exception as e:
                print(f"\n[Error during generation]: {e}")
                break


if __name__ == "__main__":
    main(state, execution_state)
